@echo off
:: -----------------------------------------------------------------------------
::  melcom's Galaxy Plugin Scout  -  Dry-Run Launcher
::  Double-click to run a full analysis without changing any files.
::  Doppelklick fuer eine vollstaendige Analyse ohne Dateiänderungen.
:: -----------------------------------------------------------------------------
title melcom's Galaxy Plugin Scout [DRY-RUN]

:: Try to enable ANSI colours in Windows Console
reg add HKCU\Console /v VirtualTerminalLevel /t REG_DWORD /d 1 /f >nul 2>&1

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0GalaxyPluginScout.ps1" -DryRun

echo.
pause